# RESTful Booker API Automation Framework

API testing project built with Python, Playwright APIRequestContext, and Pytest.

## API under test

- Base URL: https://restful-booker.herokuapp.com
- Documentation: https://restful-booker.herokuapp.com/apidoc/index.html

## Coverage

- Authentication token generation
- GET all bookings and GET booking by ID
- POST create booking
- PUT full update
- PATCH partial update
- DELETE booking
- Query filtering
- JSON field and data validation
- Negative authentication and missing-booking scenarios
- Pytest markers and HTML reports

## Project structure

```text
booking_api_automation/
├── clients/
│   ├── __init__.py
│   └── booking_client.py
├── test_data/
│   └── booking.json
├── tests/
│   ├── __init__.py
│   ├── test_auth_api.py
│   └── test_booking_api.py
├── reports/
├── conftest.py
├── pytest.ini
├── requirements.txt
└── README.md
```

## Run in PyCharm

1. Open the extracted `booking_api_automation` folder in PyCharm.
2. Configure a Python interpreter or create a virtual environment.
3. Open the PyCharm terminal.
4. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

5. Run all tests:

   ```bash
   pytest
   ```

6. Generate an HTML report:

   ```bash
   mkdir -p reports
   pytest --html=reports/report.html --self-contained-html
   ```

## Notes

This is a public demo API. It can be rate-limited, reset, or temporarily unavailable, and its behavior may change. Some negative-case status codes are checked against documented/observed demo behavior. Review response bodies when a test fails.

The authentication token is sent using the `Cookie: token=...` header, as required by the RESTful Booker API for protected booking operations. Never commit real credentials or secrets.
